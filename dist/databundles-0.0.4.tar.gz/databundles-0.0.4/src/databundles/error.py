'''
Created on Jun 15, 2012

@author: eric
'''

class ConfigError(object):
    '''
    General configuration error
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        pass