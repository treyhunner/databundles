'''
Created on Jun 10, 2012

@author: eric
'''

class Repository(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    